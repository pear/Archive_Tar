  test archive containing a > 8G file, exceeding the limit of traditional tar
